# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import django
from django.test import TestCase
import os, sys
from random import randint
import random
import function
from wsgiref.util import FileWrapper
import mimetypes

